"""StructSplat CUDA extension helpers."""

