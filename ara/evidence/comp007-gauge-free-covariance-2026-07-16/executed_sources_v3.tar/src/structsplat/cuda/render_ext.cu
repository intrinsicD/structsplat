#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAException.h>
#include <torch/extension.h>

#include <algorithm>
#include <vector>

namespace {

__device__ __forceinline__ void support_bounds(
    const float* means,
    const int64_t* radii,
    int i,
    int height,
    int width,
    int& x0,
    int& y0,
    int& tx,
    int& ty) {
  float mx = means[i * 2 + 0];
  float my = means[i * 2 + 1];
  // A NaN/Inf mean (e.g. a diverged fit) casts to INT_MAX and then ix+rx signed-overflows and
  // wraps negative, defeating both clamps and producing a bogus positive tile size that reads
  // out of bounds. Drop such Gaussians (empty tile), matching the reference's zero contribution.
  if (!isfinite(mx) || !isfinite(my)) {
    x0 = 0;
    y0 = 0;
    tx = 0;
    ty = 0;
    return;
  }
  int rx = static_cast<int>(radii[i * 2 + 0]);
  int ry = static_cast<int>(radii[i * 2 + 1]);
  // Clamp the rounded center into a range where ix +/- r cannot overflow int before the cast.
  float fx = nearbyintf(mx);
  float fy = nearbyintf(my);
  fx = fminf(fmaxf(fx, static_cast<float>(-(rx + 1))), static_cast<float>(width + rx));
  fy = fminf(fmaxf(fy, static_cast<float>(-(ry + 1))), static_cast<float>(height + ry));
  int ix = static_cast<int>(fx);
  int iy = static_cast<int>(fy);
  x0 = max(ix - rx, 0);
  int x1 = min(ix + rx, width - 1);
  y0 = max(iy - ry, 0);
  int y1 = min(iy + ry, height - 1);
  tx = max(x1 - x0 + 1, 0);
  ty = max(y1 - y0 + 1, 0);
}

__device__ __forceinline__ float visible_weight(float raw, bool support_fade, float tail) {
  if (!support_fade) {
    return raw;
  }
  return fmaxf(raw - tail, 0.0f);
}

__device__ __forceinline__ float dvisible_dq(float raw, bool support_fade, float tail) {
  if (support_fade && raw <= tail) {
    return 0.0f;
  }
  return -0.5f * raw;
}

__global__ void accumulate_kernel(
    const float* __restrict__ means,
    const float* __restrict__ conics,
    const float* __restrict__ colors,
    const int64_t* __restrict__ radii,
    const float* __restrict__ opacities,
    int n,
    int height,
    int width,
    bool has_opacity,
    bool normalize,
    bool support_fade,
    float tail,
    float* __restrict__ num,
    float* __restrict__ den) {
  int i = blockIdx.x;
  if (i >= n) {
    return;
  }
  int x0, y0, tx, ty;
  support_bounds(means, radii, i, height, width, x0, y0, tx, ty);
  int total = tx * ty;
  if (total <= 0) {
    return;
  }

  float mx = means[i * 2 + 0];
  float my = means[i * 2 + 1];
  float a = conics[i * 3 + 0];
  float b = conics[i * 3 + 1];
  float c = conics[i * 3 + 2];
  float op = has_opacity ? opacities[i] : 1.0f;
  float cr = colors[i * 3 + 0];
  float cg = colors[i * 3 + 1];
  float cb = colors[i * 3 + 2];

  for (int t = threadIdx.x; t < total; t += blockDim.x) {
    int px = x0 + (t % tx);
    int py = y0 + (t / tx);
    float dx = static_cast<float>(px) - mx;
    float dy = static_cast<float>(py) - my;
    float q = a * dx * dx + 2.0f * b * dx * dy + c * dy * dy;
    float w = visible_weight(expf(-0.5f * q), support_fade, tail) * op;
    int flat = py * width + px;
    atomicAdd(&num[flat * 3 + 0], w * cr);
    atomicAdd(&num[flat * 3 + 1], w * cg);
    atomicAdd(&num[flat * 3 + 2], w * cb);
    if (normalize) {
      atomicAdd(&den[flat], w);
    }
  }
}

__global__ void finalize_kernel(
    const float* __restrict__ num,
    const float* __restrict__ den,
    int pixels,
    bool normalize,
    float eps,
    float* __restrict__ out) {
  int flat = blockIdx.x * blockDim.x + threadIdx.x;
  if (flat >= pixels) {
    return;
  }
  if (normalize) {
    float denom = den[flat] + eps;
    out[flat * 3 + 0] = num[flat * 3 + 0] / denom;
    out[flat * 3 + 1] = num[flat * 3 + 1] / denom;
    out[flat * 3 + 2] = num[flat * 3 + 2] / denom;
  } else {
    out[flat * 3 + 0] = num[flat * 3 + 0];
    out[flat * 3 + 1] = num[flat * 3 + 1];
    out[flat * 3 + 2] = num[flat * 3 + 2];
  }
}

__global__ void tiled_forward_kernel(
    const float* __restrict__ means,
    const float* __restrict__ conics,
    const float* __restrict__ colors,
    const int64_t* __restrict__ radii,
    const float* __restrict__ opacities,
    const int64_t* __restrict__ tile_gids,
    const int64_t* __restrict__ tile_offsets,
    int height,
    int width,
    int tiles_x,
    int tile_size,
    bool has_opacity,
    bool normalize,
    float eps,
    bool support_fade,
    float tail,
    float* __restrict__ out,
    float* __restrict__ den) {
  int tile = blockIdx.x;
  int local = threadIdx.x;
  int tile_pixels = tile_size * tile_size;
  if (local >= tile_pixels) {
    return;
  }
  int tile_x = tile % tiles_x;
  int tile_y = tile / tiles_x;
  int px = tile_x * tile_size + (local % tile_size);
  int py = tile_y * tile_size + (local / tile_size);
  if (px >= width || py >= height) {
    return;
  }

  float nr = 0.0f;
  float ng = 0.0f;
  float nb = 0.0f;
  float d = 0.0f;
  int64_t start = tile_offsets[tile];
  int64_t end = tile_offsets[tile + 1];
  for (int64_t p = start; p < end; ++p) {
    int i = static_cast<int>(tile_gids[p]);
    int x0, y0, tx, ty;
    support_bounds(means, radii, i, height, width, x0, y0, tx, ty);
    if (px < x0 || px >= x0 + tx || py < y0 || py >= y0 + ty) {
      continue;
    }
    float mx = means[i * 2 + 0];
    float my = means[i * 2 + 1];
    float dx = static_cast<float>(px) - mx;
    float dy = static_cast<float>(py) - my;
    float a = conics[i * 3 + 0];
    float b = conics[i * 3 + 1];
    float c = conics[i * 3 + 2];
    float q = a * dx * dx + 2.0f * b * dx * dy + c * dy * dy;
    float op = has_opacity ? opacities[i] : 1.0f;
    float weight = visible_weight(expf(-0.5f * q), support_fade, tail) * op;
    nr += weight * colors[i * 3 + 0];
    ng += weight * colors[i * 3 + 1];
    nb += weight * colors[i * 3 + 2];
    d += weight;
  }

  int flat = py * width + px;
  den[flat] = d;
  if (normalize) {
    float denom = d + eps;
    out[flat * 3 + 0] = nr / denom;
    out[flat * 3 + 1] = ng / denom;
    out[flat * 3 + 2] = nb / denom;
  } else {
    out[flat * 3 + 0] = nr;
    out[flat * 3 + 1] = ng;
    out[flat * 3 + 2] = nb;
  }
}

__global__ void backward_kernel(
    const float* __restrict__ grad_out,
    const float* __restrict__ means,
    const float* __restrict__ conics,
    const float* __restrict__ colors,
    const int64_t* __restrict__ radii,
    const float* __restrict__ opacities,
    const float* __restrict__ den,
    const float* __restrict__ out,
    int n,
    int height,
    int width,
    bool has_opacity,
    bool normalize,
    float eps,
    bool support_fade,
    float tail,
    float* __restrict__ grad_means,
    float* __restrict__ grad_conics,
    float* __restrict__ grad_colors,
    float* __restrict__ grad_opacities) {
  int i = blockIdx.x;
  if (i >= n) {
    return;
  }
  int x0, y0, tx, ty;
  support_bounds(means, radii, i, height, width, x0, y0, tx, ty);
  int total = tx * ty;
  if (total <= 0) {
    return;
  }

  float mx = means[i * 2 + 0];
  float my = means[i * 2 + 1];
  float a = conics[i * 3 + 0];
  float b = conics[i * 3 + 1];
  float c = conics[i * 3 + 2];
  float op = has_opacity ? opacities[i] : 1.0f;
  float cr = colors[i * 3 + 0];
  float cg = colors[i * 3 + 1];
  float cb = colors[i * 3 + 2];

  float gm0 = 0.0f;
  float gm1 = 0.0f;
  float ga = 0.0f;
  float gb = 0.0f;
  float gc = 0.0f;
  float gcr = 0.0f;
  float gcg = 0.0f;
  float gcb = 0.0f;
  float gop = 0.0f;

  for (int t = threadIdx.x; t < total; t += blockDim.x) {
    int px = x0 + (t % tx);
    int py = y0 + (t / tx);
    int flat = py * width + px;
    float dx = static_cast<float>(px) - mx;
    float dy = static_cast<float>(py) - my;
    float q = a * dx * dx + 2.0f * b * dx * dy + c * dy * dy;
    float raw = expf(-0.5f * q);
    float base = visible_weight(raw, support_fade, tail);
    float w = base * op;

    float gr = grad_out[flat * 3 + 0];
    float gg = grad_out[flat * 3 + 1];
    float gbch = grad_out[flat * 3 + 2];
    float dw;
    if (normalize) {
      float denom = den[flat] + eps;
      float dnum_r = gr / denom;
      float dnum_g = gg / denom;
      float dnum_b = gbch / denom;
      float dden = -(
          gr * out[flat * 3 + 0] +
          gg * out[flat * 3 + 1] +
          gbch * out[flat * 3 + 2]) / denom;
      gcr += dnum_r * w;
      gcg += dnum_g * w;
      gcb += dnum_b * w;
      dw = dnum_r * cr + dnum_g * cg + dnum_b * cb + dden;
    } else {
      gcr += gr * w;
      gcg += gg * w;
      gcb += gbch * w;
      dw = gr * cr + gg * cg + gbch * cb;
    }

    float dbase = dw * op;
    if (has_opacity) {
      gop += dw * base;
    }
    float dq = dvisible_dq(raw, support_fade, tail) * dbase;
    gm0 += dq * (-2.0f * a * dx - 2.0f * b * dy);
    gm1 += dq * (-2.0f * b * dx - 2.0f * c * dy);
    ga += dq * dx * dx;
    gb += dq * 2.0f * dx * dy;
    gc += dq * dy * dy;
  }

  atomicAdd(&grad_means[i * 2 + 0], gm0);
  atomicAdd(&grad_means[i * 2 + 1], gm1);
  atomicAdd(&grad_conics[i * 3 + 0], ga);
  atomicAdd(&grad_conics[i * 3 + 1], gb);
  atomicAdd(&grad_conics[i * 3 + 2], gc);
  atomicAdd(&grad_colors[i * 3 + 0], gcr);
  atomicAdd(&grad_colors[i * 3 + 1], gcg);
  atomicAdd(&grad_colors[i * 3 + 2], gcb);
  if (has_opacity) {
    atomicAdd(&grad_opacities[i], gop);
  }
}

__device__ __forceinline__ float warp_reduce_sum(float value) {
  #pragma unroll
  for (int offset = 16; offset > 0; offset >>= 1) {
    value += __shfl_down_sync(0xffffffffu, value, offset);
  }
  return value;
}

// Experimental untiled backward: preserve one block per Gaussian and the baseline thread-local
// pixel accumulation, then reduce the 8/9 gradient components within the block. Because no other
// block owns Gaussian i, thread 0 can write each result directly instead of issuing 256 contended
// atomicAdds per component. The baseline kernel remains available and is still the default.
__global__ void backward_block_reduce_kernel(
    const float* __restrict__ grad_out,
    const float* __restrict__ means,
    const float* __restrict__ conics,
    const float* __restrict__ colors,
    const int64_t* __restrict__ radii,
    const float* __restrict__ opacities,
    const float* __restrict__ den,
    const float* __restrict__ out,
    int n,
    int height,
    int width,
    bool has_opacity,
    bool normalize,
    float eps,
    bool support_fade,
    float tail,
    float* __restrict__ grad_means,
    float* __restrict__ grad_conics,
    float* __restrict__ grad_colors,
    float* __restrict__ grad_opacities) {
  int i = blockIdx.x;
  if (i >= n) {
    return;
  }
  int x0, y0, tx, ty;
  support_bounds(means, radii, i, height, width, x0, y0, tx, ty);
  int total = tx * ty;
  if (total <= 0) {
    return;
  }

  float mx = means[i * 2 + 0];
  float my = means[i * 2 + 1];
  float a = conics[i * 3 + 0];
  float b = conics[i * 3 + 1];
  float c = conics[i * 3 + 2];
  float op = has_opacity ? opacities[i] : 1.0f;
  float cr = colors[i * 3 + 0];
  float cg = colors[i * 3 + 1];
  float cb = colors[i * 3 + 2];

  float gradients[9] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
  for (int t = threadIdx.x; t < total; t += blockDim.x) {
    int px = x0 + (t % tx);
    int py = y0 + (t / tx);
    int flat = py * width + px;
    float dx = static_cast<float>(px) - mx;
    float dy = static_cast<float>(py) - my;
    float q = a * dx * dx + 2.0f * b * dx * dy + c * dy * dy;
    float raw = expf(-0.5f * q);
    float base = visible_weight(raw, support_fade, tail);
    float weight = base * op;

    float gr = grad_out[flat * 3 + 0];
    float gg = grad_out[flat * 3 + 1];
    float gbch = grad_out[flat * 3 + 2];
    float dw;
    if (normalize) {
      float denom = den[flat] + eps;
      float dnum_r = gr / denom;
      float dnum_g = gg / denom;
      float dnum_b = gbch / denom;
      float dden = -(
          gr * out[flat * 3 + 0] +
          gg * out[flat * 3 + 1] +
          gbch * out[flat * 3 + 2]) / denom;
      gradients[5] += dnum_r * weight;
      gradients[6] += dnum_g * weight;
      gradients[7] += dnum_b * weight;
      dw = dnum_r * cr + dnum_g * cg + dnum_b * cb + dden;
    } else {
      gradients[5] += gr * weight;
      gradients[6] += gg * weight;
      gradients[7] += gbch * weight;
      dw = gr * cr + gg * cg + gbch * cb;
    }

    float dbase = dw * op;
    if (has_opacity) {
      gradients[8] += dw * base;
    }
    float dq = dvisible_dq(raw, support_fade, tail) * dbase;
    gradients[0] += dq * (-2.0f * a * dx - 2.0f * b * dy);
    gradients[1] += dq * (-2.0f * b * dx - 2.0f * c * dy);
    gradients[2] += dq * dx * dx;
    gradients[3] += dq * 2.0f * dx * dy;
    gradients[4] += dq * dy * dy;
  }

  constexpr int kGradientComponents = 9;
  constexpr int kWarpsPerBlock = 8;
  __shared__ float warp_sums[kGradientComponents * kWarpsPerBlock];
  int lane = threadIdx.x & 31;
  int warp = threadIdx.x >> 5;
  #pragma unroll
  for (int component = 0; component < kGradientComponents; ++component) {
    gradients[component] = warp_reduce_sum(gradients[component]);
    if (lane == 0) {
      warp_sums[component * kWarpsPerBlock + warp] = gradients[component];
    }
  }
  __syncthreads();

  if (warp == 0) {
    #pragma unroll
    for (int component = 0; component < kGradientComponents; ++component) {
      float value = lane < kWarpsPerBlock
          ? warp_sums[component * kWarpsPerBlock + lane]
          : 0.0f;
      value = warp_reduce_sum(value);
      if (lane == 0) {
        warp_sums[component * kWarpsPerBlock] = value;
      }
    }
  }
  __syncthreads();

  if (threadIdx.x == 0) {
    grad_means[i * 2 + 0] = warp_sums[0 * kWarpsPerBlock];
    grad_means[i * 2 + 1] = warp_sums[1 * kWarpsPerBlock];
    grad_conics[i * 3 + 0] = warp_sums[2 * kWarpsPerBlock];
    grad_conics[i * 3 + 1] = warp_sums[3 * kWarpsPerBlock];
    grad_conics[i * 3 + 2] = warp_sums[4 * kWarpsPerBlock];
    grad_colors[i * 3 + 0] = warp_sums[5 * kWarpsPerBlock];
    grad_colors[i * 3 + 1] = warp_sums[6 * kWarpsPerBlock];
    grad_colors[i * 3 + 2] = warp_sums[7 * kWarpsPerBlock];
    if (has_opacity) {
      grad_opacities[i] = warp_sums[8 * kWarpsPerBlock];
    }
  }
}

__global__ void tiled_backward_kernel(
    const float* __restrict__ grad_out,
    const float* __restrict__ means,
    const float* __restrict__ conics,
    const float* __restrict__ colors,
    const int64_t* __restrict__ radii,
    const float* __restrict__ opacities,
    const float* __restrict__ den,
    const float* __restrict__ out,
    const int64_t* __restrict__ tile_gids,
    const int64_t* __restrict__ tile_offsets,
    int height,
    int width,
    int tiles_x,
    int tile_size,
    bool has_opacity,
    bool normalize,
    float eps,
    bool support_fade,
    float tail,
    float* __restrict__ grad_means,
    float* __restrict__ grad_conics,
    float* __restrict__ grad_colors,
    float* __restrict__ grad_opacities) {
  int tile = blockIdx.x;
  int local = threadIdx.x;
  int tile_pixels = tile_size * tile_size;
  if (local >= tile_pixels) {
    return;
  }
  int tile_x = tile % tiles_x;
  int tile_y = tile / tiles_x;
  int px = tile_x * tile_size + (local % tile_size);
  int py = tile_y * tile_size + (local / tile_size);
  if (px >= width || py >= height) {
    return;
  }
  int flat = py * width + px;
  float gr = grad_out[flat * 3 + 0];
  float gg = grad_out[flat * 3 + 1];
  float gbch = grad_out[flat * 3 + 2];

  int64_t start = tile_offsets[tile];
  int64_t end = tile_offsets[tile + 1];
  for (int64_t p = start; p < end; ++p) {
    int i = static_cast<int>(tile_gids[p]);
    int x0, y0, tx, ty;
    support_bounds(means, radii, i, height, width, x0, y0, tx, ty);
    if (px < x0 || px >= x0 + tx || py < y0 || py >= y0 + ty) {
      continue;
    }

    float mx = means[i * 2 + 0];
    float my = means[i * 2 + 1];
    float dx = static_cast<float>(px) - mx;
    float dy = static_cast<float>(py) - my;
    float a = conics[i * 3 + 0];
    float b = conics[i * 3 + 1];
    float c = conics[i * 3 + 2];
    float op = has_opacity ? opacities[i] : 1.0f;
    float cr = colors[i * 3 + 0];
    float cg = colors[i * 3 + 1];
    float cb = colors[i * 3 + 2];
    float q = a * dx * dx + 2.0f * b * dx * dy + c * dy * dy;
    float raw = expf(-0.5f * q);
    float base = visible_weight(raw, support_fade, tail);
    float weight = base * op;

    float dw;
    if (normalize) {
      float denom = den[flat] + eps;
      float dnum_r = gr / denom;
      float dnum_g = gg / denom;
      float dnum_b = gbch / denom;
      float dden = -(
          gr * out[flat * 3 + 0] +
          gg * out[flat * 3 + 1] +
          gbch * out[flat * 3 + 2]) / denom;
      atomicAdd(&grad_colors[i * 3 + 0], dnum_r * weight);
      atomicAdd(&grad_colors[i * 3 + 1], dnum_g * weight);
      atomicAdd(&grad_colors[i * 3 + 2], dnum_b * weight);
      dw = dnum_r * cr + dnum_g * cg + dnum_b * cb + dden;
    } else {
      atomicAdd(&grad_colors[i * 3 + 0], gr * weight);
      atomicAdd(&grad_colors[i * 3 + 1], gg * weight);
      atomicAdd(&grad_colors[i * 3 + 2], gbch * weight);
      dw = gr * cr + gg * cg + gbch * cb;
    }

    float dbase = dw * op;
    if (has_opacity) {
      atomicAdd(&grad_opacities[i], dw * base);
    }
    float dq = dvisible_dq(raw, support_fade, tail) * dbase;
    atomicAdd(&grad_means[i * 2 + 0], dq * (-2.0f * a * dx - 2.0f * b * dy));
    atomicAdd(&grad_means[i * 2 + 1], dq * (-2.0f * b * dx - 2.0f * c * dy));
    atomicAdd(&grad_conics[i * 3 + 0], dq * dx * dx);
    atomicAdd(&grad_conics[i * 3 + 1], dq * 2.0f * dx * dy);
    atomicAdd(&grad_conics[i * 3 + 2], dq * dy * dy);
  }
}

}  // namespace

std::vector<torch::Tensor> structsplat_render_forward_cuda(
    torch::Tensor means,
    torch::Tensor conics,
    torch::Tensor colors,
    torch::Tensor radii,
    torch::Tensor opacities,
    int64_t height,
    int64_t width,
    bool normalize,
    double eps,
    bool support_fade,
    double sigma_cutoff) {
  int n = static_cast<int>(means.size(0));
  int h = static_cast<int>(height);
  int w = static_cast<int>(width);
  int pixels = h * w;
  auto out_flat = torch::zeros({pixels, 3}, means.options());
  auto num = torch::zeros({pixels, 3}, means.options());
  auto den = torch::zeros({pixels}, means.options());
  if (pixels > 0) {
    cudaStream_t stream = at::cuda::getCurrentCUDAStream();
    constexpr int threads = 256;
    float tail = expf(-0.5f * static_cast<float>(sigma_cutoff * sigma_cutoff));
    if (n > 0) {
      accumulate_kernel<<<n, threads, 0, stream>>>(
          means.data_ptr<float>(),
          conics.data_ptr<float>(),
          colors.data_ptr<float>(),
          radii.data_ptr<int64_t>(),
          opacities.numel() ? opacities.data_ptr<float>() : nullptr,
          n,
          h,
          w,
          opacities.numel() > 0,
          normalize,
          support_fade,
          tail,
          num.data_ptr<float>(),
          den.data_ptr<float>());
      C10_CUDA_KERNEL_LAUNCH_CHECK();
    }
    // Run finalize even when n == 0 so the output is defined zeros, matching the reference
    // renderer (num/den are all-zero, so normalized -> 0 and additive -> 0). Previously the
    // caller received uninitialized allocator memory for an empty field (CORE-004).
    int blocks = (pixels + threads - 1) / threads;
    finalize_kernel<<<blocks, threads, 0, stream>>>(
        num.data_ptr<float>(),
        den.data_ptr<float>(),
        pixels,
        normalize,
        static_cast<float>(eps),
        out_flat.data_ptr<float>());
    C10_CUDA_KERNEL_LAUNCH_CHECK();
  }
  return {out_flat.view({height, width, 3}), den.view({height, width})};
}

std::vector<torch::Tensor> structsplat_render_forward_tiled_cuda(
    torch::Tensor means,
    torch::Tensor conics,
    torch::Tensor colors,
    torch::Tensor radii,
    torch::Tensor opacities,
    torch::Tensor tile_gids,
    torch::Tensor tile_offsets,
    int64_t height,
    int64_t width,
    bool normalize,
    double eps,
    int64_t tile_size,
    bool support_fade,
    double sigma_cutoff) {
  int h = static_cast<int>(height);
  int w = static_cast<int>(width);
  int ts = static_cast<int>(tile_size);
  int pixels = h * w;
  int tiles_x = (w + ts - 1) / ts;
  int tiles_y = (h + ts - 1) / ts;
  int num_tiles = tiles_x * tiles_y;
  TORCH_CHECK(tile_offsets.size(0) == num_tiles + 1,
              "tile_offsets length must equal num_tiles + 1");
  auto out_flat = torch::zeros({pixels, 3}, means.options());
  auto den = torch::zeros({pixels}, means.options());
  if (pixels > 0 && num_tiles > 0) {
    cudaStream_t stream = at::cuda::getCurrentCUDAStream();
    int threads = ts * ts;
    float tail = expf(-0.5f * static_cast<float>(sigma_cutoff * sigma_cutoff));
    tiled_forward_kernel<<<num_tiles, threads, 0, stream>>>(
        means.data_ptr<float>(),
        conics.data_ptr<float>(),
        colors.data_ptr<float>(),
        radii.data_ptr<int64_t>(),
        opacities.numel() ? opacities.data_ptr<float>() : nullptr,
        tile_gids.data_ptr<int64_t>(),
        tile_offsets.data_ptr<int64_t>(),
        h,
        w,
        tiles_x,
        ts,
        opacities.numel() > 0,
        normalize,
        static_cast<float>(eps),
        support_fade,
        tail,
        out_flat.data_ptr<float>(),
        den.data_ptr<float>());
    C10_CUDA_KERNEL_LAUNCH_CHECK();
  }
  return {out_flat.view({height, width, 3}), den.view({height, width})};
}

std::vector<torch::Tensor> structsplat_render_backward_cuda(
    torch::Tensor grad_out,
    torch::Tensor means,
    torch::Tensor conics,
    torch::Tensor colors,
    torch::Tensor radii,
    torch::Tensor opacities,
    torch::Tensor den,
    torch::Tensor out,
    bool normalize,
    double eps,
    bool support_fade,
    double sigma_cutoff) {
  int n = static_cast<int>(means.size(0));
  int h = static_cast<int>(out.size(0));
  int w = static_cast<int>(out.size(1));
  auto grad_means = torch::zeros_like(means);
  auto grad_conics = torch::zeros_like(conics);
  auto grad_colors = torch::zeros_like(colors);
  auto grad_opacities = opacities.numel()
      ? torch::zeros_like(opacities)
      : torch::empty({0}, means.options());
  if (n > 0 && h > 0 && w > 0) {
    cudaStream_t stream = at::cuda::getCurrentCUDAStream();
    constexpr int threads = 256;
    float tail = expf(-0.5f * static_cast<float>(sigma_cutoff * sigma_cutoff));
    backward_kernel<<<n, threads, 0, stream>>>(
        grad_out.data_ptr<float>(),
        means.data_ptr<float>(),
        conics.data_ptr<float>(),
        colors.data_ptr<float>(),
        radii.data_ptr<int64_t>(),
        opacities.numel() ? opacities.data_ptr<float>() : nullptr,
        den.data_ptr<float>(),
        out.data_ptr<float>(),
        n,
        h,
        w,
        opacities.numel() > 0,
        normalize,
        static_cast<float>(eps),
        support_fade,
        tail,
        grad_means.data_ptr<float>(),
        grad_conics.data_ptr<float>(),
        grad_colors.data_ptr<float>(),
        grad_opacities.numel() ? grad_opacities.data_ptr<float>() : nullptr);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
  }
  return {grad_means, grad_conics, grad_colors, grad_opacities};
}

std::vector<torch::Tensor> structsplat_render_backward_block_reduce_cuda(
    torch::Tensor grad_out,
    torch::Tensor means,
    torch::Tensor conics,
    torch::Tensor colors,
    torch::Tensor radii,
    torch::Tensor opacities,
    torch::Tensor den,
    torch::Tensor out,
    bool normalize,
    double eps,
    bool support_fade,
    double sigma_cutoff) {
  int n = static_cast<int>(means.size(0));
  int h = static_cast<int>(out.size(0));
  int w = static_cast<int>(out.size(1));
  auto grad_means = torch::zeros_like(means);
  auto grad_conics = torch::zeros_like(conics);
  auto grad_colors = torch::zeros_like(colors);
  auto grad_opacities = opacities.numel()
      ? torch::zeros_like(opacities)
      : torch::empty({0}, means.options());
  if (n > 0 && h > 0 && w > 0) {
    cudaStream_t stream = at::cuda::getCurrentCUDAStream();
    constexpr int threads = 256;
    float tail = expf(-0.5f * static_cast<float>(sigma_cutoff * sigma_cutoff));
    backward_block_reduce_kernel<<<n, threads, 0, stream>>>(
        grad_out.data_ptr<float>(),
        means.data_ptr<float>(),
        conics.data_ptr<float>(),
        colors.data_ptr<float>(),
        radii.data_ptr<int64_t>(),
        opacities.numel() ? opacities.data_ptr<float>() : nullptr,
        den.data_ptr<float>(),
        out.data_ptr<float>(),
        n,
        h,
        w,
        opacities.numel() > 0,
        normalize,
        static_cast<float>(eps),
        support_fade,
        tail,
        grad_means.data_ptr<float>(),
        grad_conics.data_ptr<float>(),
        grad_colors.data_ptr<float>(),
        grad_opacities.numel() ? grad_opacities.data_ptr<float>() : nullptr);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
  }
  return {grad_means, grad_conics, grad_colors, grad_opacities};
}

std::vector<torch::Tensor> structsplat_render_backward_tiled_cuda(
    torch::Tensor grad_out,
    torch::Tensor means,
    torch::Tensor conics,
    torch::Tensor colors,
    torch::Tensor radii,
    torch::Tensor opacities,
    torch::Tensor den,
    torch::Tensor out,
    torch::Tensor tile_gids,
    torch::Tensor tile_offsets,
    bool normalize,
    double eps,
    int64_t tile_size,
    bool support_fade,
    double sigma_cutoff) {
  int n = static_cast<int>(means.size(0));
  int h = static_cast<int>(out.size(0));
  int w = static_cast<int>(out.size(1));
  int ts = static_cast<int>(tile_size);
  int tiles_x = (w + ts - 1) / ts;
  int tiles_y = (h + ts - 1) / ts;
  int num_tiles = tiles_x * tiles_y;
  TORCH_CHECK(tile_offsets.size(0) == num_tiles + 1,
              "tile_offsets length must equal num_tiles + 1");
  auto grad_means = torch::zeros_like(means);
  auto grad_conics = torch::zeros_like(conics);
  auto grad_colors = torch::zeros_like(colors);
  auto grad_opacities = opacities.numel()
      ? torch::zeros_like(opacities)
      : torch::empty({0}, means.options());
  if (n > 0 && h > 0 && w > 0 && num_tiles > 0) {
    cudaStream_t stream = at::cuda::getCurrentCUDAStream();
    int threads = ts * ts;
    float tail = expf(-0.5f * static_cast<float>(sigma_cutoff * sigma_cutoff));
    tiled_backward_kernel<<<num_tiles, threads, 0, stream>>>(
        grad_out.data_ptr<float>(),
        means.data_ptr<float>(),
        conics.data_ptr<float>(),
        colors.data_ptr<float>(),
        radii.data_ptr<int64_t>(),
        opacities.numel() ? opacities.data_ptr<float>() : nullptr,
        den.data_ptr<float>(),
        out.data_ptr<float>(),
        tile_gids.data_ptr<int64_t>(),
        tile_offsets.data_ptr<int64_t>(),
        h,
        w,
        tiles_x,
        ts,
        opacities.numel() > 0,
        normalize,
        static_cast<float>(eps),
        support_fade,
        tail,
        grad_means.data_ptr<float>(),
        grad_conics.data_ptr<float>(),
        grad_colors.data_ptr<float>(),
        grad_opacities.numel() ? grad_opacities.data_ptr<float>() : nullptr);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
  }
  return {grad_means, grad_conics, grad_colors, grad_opacities};
}
